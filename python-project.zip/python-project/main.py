
# College Canteen Order and Billing System

def display_menu():
    print("\n========== CANTEEN MENU ==========")
    print("1. Sandwich  - Rs. 50")
    print("2. Burger    - Rs. 60")
    print("3. Pizza     - Rs. 100")
    print("4. Tea       - Rs. 15")
    print("5. Coffee    - Rs. 25")
    print("6. Exit")
    print("==================================")


def generate_bill(order):
    print("\n========== FINAL BILL ==========")
    print("Item\t\tQty\tPrice")

    subtotal = 0

    for item, details in order.items():
        quantity = details[0]
        price = details[1]
        amount = quantity * price

        subtotal += amount

        print(f"{item}\t\t{quantity}\tRs.{amount}")

    gst = subtotal * 0.05
    total = subtotal + gst

    print("--------------------------------")
    print(f"Subtotal:       Rs.{subtotal:.2f}")
    print(f"GST (5%):       Rs.{gst:.2f}")
    print(f"Grand Total:    Rs.{total:.2f}")
    print("================================")
    print("Thank you! Visit Again!")


def main():
    menu = {
        1: ("Sandwich", 50),
        2: ("Burger", 60),
        3: ("Pizza", 100),
        4: ("Tea", 15),
        5: ("Coffee", 25)
    }

    order = {}

    print("WELCOME TO COLLEGE CANTEEN")

    student_name = input("Enter student name: ")

    while True:
        display_menu()

        try:
            choice = int(input("Enter your choice: "))

            if choice == 6:
                break

            if choice not in menu:
                print("Invalid choice! Try again.")
                continue

            quantity = int(input("Enter quantity: "))

            if quantity <= 0:
                print("Please enter a valid quantity.")
                continue

            item_name, price = menu[choice]

            if item_name in order:
                order[item_name][0] += quantity
            else:
                order[item_name] = [quantity, price]

            print(item_name, "added to your order!")

        except ValueError:
            print("Please enter numbers only.")

    if order:
        print("\nStudent Name:", student_name)
        generate_bill(order)
    else:
        print("\nNo items ordered.")


main()
